# -*- coding: utf-8 -*-
import logging
import os
import sys
from logging import handlers
import grpc
from OPCGatePy import opc_pb2_grpc
from OPCGatePy import opc_pb2
from google.protobuf.struct_pb2 import Value, ListValue
from OPCGatePy.tag_manager import TagManager
from OPCGatePy.grpc_connector import OPCGateGrpcConnector
from OPCGatePy.read_rpc import ReadRPC
from OPCGatePy.bind_tag_rpc import BindTagRPC
from OPCGatePy.create_rpc import CreateRPC
from OPCGatePy.utils import DataType
from OPCGatePy.write_rpc import WriteRPC, WriteBooleanRPC, WriteNumberRPC, WriteStringRPC
from OPCGatePy.valid_rpc import ValidRPC
from OPCGatePy.enum_tags_rpc import EnumTagsRPC


LOGGING_MSG_FORMAT = '[%(asctime)s] [%(levelname)s] %(message)s'
LOGGING_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'


# OPC网关客户端
class OPCGateClient:
    def __init__(self, ip, port):
        self.__set_logger()
        self.tag_names_cache = []  # transmit 转移数据时 缓存转移的位号
        self.show_exception = False
        self._tag_manager = TagManager()
        self.__connector = OPCGateGrpcConnector(ip, port, self._tag_manager, self.__logger)

    # 设置日志
    def __set_logger(self):
        logging.basicConfig(level=logging.INFO, format=LOGGING_MSG_FORMAT, datefmt=LOGGING_DATE_FORMAT)
        self.__logger = logging.getLogger("task")
        # 设置是否打印日志到控制台
        self.__logger.propagate = True
        log_file = self.__get_or_create_log_path()
        file_handler = handlers.TimedRotatingFileHandler(log_file, 'midnight', 1)
        file_handler.setFormatter(logging.Formatter(LOGGING_MSG_FORMAT))
        self.__logger.addHandler(file_handler)

    def set_logger_level(self, lvl):
        self.__logger.setLevel(lvl)

    # 获取当前目录
    def __get_current_path(self):
        path = os.path.realpath(sys.argv[0])
        if os.path.isfile(path):
            path = os.path.dirname(path)
        return os.path.abspath(path)

    def __get_or_create_log_path(self):
        log_path = os.path.join(self.__get_current_path(), 'logs')
        if not os.path.exists(log_path):
            os.makedirs(log_path)
        log_file = os.path.join(log_path, self.__class__.__module__ + '.log')
        return log_file

    def __build_value(self, v):
        if type(v) == bool:
            val = Value(bool_value=v)
        elif type(v) == str:
            val = Value(string_value=v)
        elif v is None:
            val = Value(null_value=v)
        elif type(v) == list or type(v) == tuple:
            if len(v) == 0:
                self.error("空List类型无法写入")
                return None
            ret = []
            for o in v:
                ret.append(self.__build_value(o))
            val = Value(list_value=ListValue(values=ret))
        else:
            val = Value(number_value=v)
        return val

    # 更新{位号名：值}键值对Dict快速创建对象
    # 如果位号已经存在则更新对应位号值
    def quick_create(self, tag_value_pairs, server=''):
        create_pairs = {}
        write_pairs = {}
        for tag, value in tag_value_pairs.items():
            if self._tag_manager.is_tag_binding(tag):
                write_pairs[tag] = value
            else:
                create_pairs[tag] = value

        if len(create_pairs) > 0:
            self.__write(create_pairs, True, server)
        if len(write_pairs) > 0:
            self.write(write_pairs, server)

    # 创建完整的单个位号对象
    # 包括位号名，类型，初始值，描述，dbindex，备注
    def tag(self, name, datatype, value=None, desc="", dbindex=4294967295, remark=""):
        val = self.__build_value(value)
        if val is None:
            return None

        dtyp = DataType.Float
        if type(datatype) == int:
            dtyp = datatype
        elif type(datatype) == DataType:
            dtyp = datatype.value
        return {
            'name': name,
            'datatype': dtyp,
            'dbindex': dbindex,
            'cachelen': 3600,
            'desc': desc,
            'remark': remark,
            'value': val
        }

    # 创建完整位号
    # tags
    #   待创建位号列表，推荐使用tag方法创建
    def create(self, tags):
        rpc = CreateRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(tags=tags)

    def read(self, tags, start=0, length=0):
        if start == 0 and length == 0:
            rets = []
            if type(tags) == tuple:
                tags = [t for t in tags]
            elif type(tags) == str:
                tags = [tags]

            sendTags = []
            for tag in tags:
                val = self._tag_manager.get_sub_tag(tag)
                if not val or val[2] != 'Good':
                    sendTags.append(tag)
                else:
                    rets.append(val)
            if len(sendTags) > 0:
                rets.extend(self.__read(sendTags, start, length))
            return rets
        return self.__read(tags, start, length)

    def __read(self, tags, start=0, length=0):
        rpc = ReadRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(tags=tags, start=start, length=length)

    def read_value(self, tags):
        results = self.read(tags)
        if len(results) == 0:
            return None

        if isinstance(tags, str):
            return results[0][1]

        if isinstance(tags, list):
            ret = [r[1] for r in results]
            return tuple(ret)

    # 添加server 可以向其他server 写数据
    # server 参数格式为 ip:port , 如： 127.0.0.1:9999
    def writeNumber(self, tag_value_pairs, server=''):
        self.__write_number(tag_value_pairs, False, server)

    # 添加server 可以向其他server 写数据
    # server 参数格式为 ip:port , 如： 127.0.0.1:9999
    def writeAndCreateNumber(self, tag_value_pairs, server=''):
        self.quick_create(tag_value_pairs, server)

    def write(self, tag_value_pairs, server=''):
        self.__write(tag_value_pairs, False, server)

    # 添加server 可以向其他server 写数据
    # server 参数格式为 ip:port , 如： 127.0.0.1:9999
    def __write(self, tag_value_pairs, create=False, server=''):
        bool_tag_value_pairs = {}
        number_tag_value_pairs = {}
        string_tag_value_pairs = {}
        other_tag_value_pairs = {}
        for tag, value in tag_value_pairs.items():
            if type(value) == bool:
                bool_tag_value_pairs[tag] = value
            elif type(value) == str:
                string_tag_value_pairs[tag] = value
            elif value is None:
                other_tag_value_pairs[tag] = value
            elif type(value) == list or type(value) == tuple:
                other_tag_value_pairs[tag] = value
            else:
                number_tag_value_pairs[tag] = value
        if len(bool_tag_value_pairs) > 0:
            self.__write_boolean(bool_tag_value_pairs, create, server)
        if len(string_tag_value_pairs) > 0:
            self.__write_string(string_tag_value_pairs, create, server)
        if len(number_tag_value_pairs) > 0:
            self.__write_number(number_tag_value_pairs, create, server)
        if len(other_tag_value_pairs) > 0:
            rpc = WriteRPC(self.__connector, self._tag_manager, self.__logger)
            rpc(tags=other_tag_value_pairs, create=create, server=server)

    def __write_boolean(self, tag_value_pairs, create=False, server=''):
        rpc = WriteBooleanRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(tags=tag_value_pairs, create=create, server=server)

    def __write_number(self, tag_value_pairs, create=False, server=''):
        rpc = WriteNumberRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(tags=tag_value_pairs, create=create, server=server)

    def __write_string(self, tag_value_pairs, create=False, server=''):
        rpc = WriteStringRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(tags=tag_value_pairs, create=create, server=server)

    # 添加server 可以向其他server 写数据
    # server 参数格式为 ip:port , 如： 127.0.0.1:9999
    def write_and_create(self, tag_value_pairs, server=''):
        self.quick_create(tag_value_pairs, server)

    def transmit(self, server, force=False):
        if force or len(self.tag_names_cache) == 0:
            tagNames = self.getAllTagNamesList()
            self.tag_names_cache = tagNames
        rets = self.read_value_dict(self.tag_names_cache)
        self.write_and_create(rets, server)

    def transmit_subscribe(self, server, force=False):
        self.transmit(server, force)
        if force or len(self.tag_names_cache) == 0:
            tagNames = self.getAllTagNamesList()
            self.tag_names_cache = tagNames
        rets = self.Subscribe(self.tag_names_cache, onlyValue=True)
        for ret in rets:
            self.write_and_create(ret, server)

    def valid(self, name):
        rpc = ValidRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(name=name)

    def getAllTags(self, group=""):
        rpc = EnumTagsRPC(self.__connector, self._tag_manager, self.__logger)
        return rpc(prefix=group)

    def read_dict(self, tags):
        res = self.read(tags)
        if len(res) == 0:
            return {}

        if isinstance(tags, str):
            return {tags: {'name': res[0][0], 'value': res[0][1], 'quality': res[0][2], 'time': res[0][3]}}

        if isinstance(tags, list):
            return {key: {'name': res[idx][0], 'value': res[idx][1], 'quality': res[idx][2], 'time': res[idx][3]}
                    for idx, key in enumerate(tags)}

    def read_value_dict(self, tags):
        results = self.read(tags)
        if len(results) == 0:
            return {}

        if isinstance(tags, str):
            return {tags: results[0][1]}

        if isinstance(tags, list):
            return {key: results[idx][1] for idx, key in enumerate(tags)}

    def getAllTagNamesList(self, group=""):
        tags = self.getAllTags(group)
        if tags is None:
            return []
        return [t.name for t in tags]

    def __UnSubscribe(self, name="Default", reconnected=True):
        self._lock.acquire()
        subscriber = self._subClient.get(name)
        if subscriber:
            subscriber.cancel()
            if not reconnected:
                del self._subClient[name]
        self._lock.release()

    def UnSubscribe(self, name="Default"):
        self.__connector.UnSubscribe(name)

    def UnSubscribeAll(self):
        self.__connector.UnSubscribeAll()

    def Subscribe(self, tags, name="Default", onlyValue=False, returnValue=True):
        rets = self.__read(tags)
        for ret in rets:
            self._tag_manager.update_sub_tags_cache({ret[0]: ret})

        def subscribe():
            rets = self.__connector.Subscribe(tags, name, onlyValue)
            for ret in rets:
                pass
        if returnValue:
            return self.__connector.Subscribe(tags, name, onlyValue)
        else:
            import threading
            threading.Thread(target=subscribe).start()

    def AddSubscribeTags(self, tags, name="Default"):
        self.__connector.AddSubscribeTags(tags, name)

    def RemoveSubscribeTags(self, tags, name="Default"):
        self.__connector.RemoveSubscribeTags(tags, name)

    def info(self, msg):
        msg = "[%s] %s" % (self.title(), msg)
        self.__logger.info(msg)

    def error(self, msg):
        msg = "[%s] %s" % (self.title(), msg)
        if self.show_exception:
            self.__logger.exception(msg)
        else:
            self.__logger.error(msg)

    def enable_show_exception(self):
        self.show_exception = True

    def title(self):
        return self.__class__.__module__ + '.' + self.__class__.__name__

    def set_max_cache(self, len):
        self.__cache_length = len

    def connected(self):
        return self.__connector.connected
