# -*- coding: utf-8 -*-
import struct
import time, datetime
from enum import Enum

from OPCGatePy import opc_pb2


class DataType(Enum):
    Currency = 6
    String = 8
    Date = 7
    Char = 16
    Byte = 17
    Short = 2
    Word = 18
    Long = 3
    DWord = 19
    LLong = 20
    QWord = 21
    Float = 4
    Double = 5
    Boolean = 11

    # 类型为上面的类型 + 8192
    StringArray = String + 8192
    DateArray = Date + 8192
    CharArray = Char + 8192
    ByteArray = Byte + 8192
    ShortArray = Short + 8192
    WordArray = Word + 8192
    LongArray = Long + 8192
    DWordArray = DWord + 8192
    LLongArray = LLong + 8192
    QWordArray = QWord + 8192
    FloatArray = Float + 8192
    DoubleArray = Double + 8192
    BooleanArray = Boolean + 8192


class BufferReader:
    def __init__(self, buffer):
        self.buffer = buffer
        self.pos = 0

    def read(self, size):
        end = self.pos + size
        data = self.buffer[self.pos: end]
        self.pos = end
        return data


def create_metadata():
    return (("ts", str(time.time())),)


def from_bytes(datatype, buffer):
    if len(buffer) == 0:
        return None
    if datatype == opc_pb2.Null:
        return None
    elif datatype == opc_pb2.Number:
        return struct.unpack('d', buffer)[0]
    elif datatype == opc_pb2.Boolean:
        return struct.unpack('?', buffer)[0]
    elif datatype == opc_pb2.String:
        size = struct.calcsize('i')
        return buffer[size:].decode('utf-8')
    elif datatype == opc_pb2.DateTime:
        sec = struct.unpack('d', buffer)[0]
        dt = datetime.datetime(1970, 1, 1, 8) + datetime.timedelta(seconds=sec)
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    elif datatype == opc_pb2.NumberArray:
        return from_bytes_array(buffer, 'd')
    elif datatype == opc_pb2.BooleanArray:
        return from_bytes_array(buffer, '?')
    elif datatype == opc_pb2.StringArray:
        return from_bytes_string_array(buffer)
    else:
        return buffer.decode('utf-8')


def from_bytes_string_array(buffer):
    '''
        字符串数组，每个元素的组成为：
            |———————————————|——————————————————————|
            字符串bytes长度   |  字符串数据Bytes
    '''
    reader = BufferReader(buffer)

    header_size = struct.calcsize('iii')
    header_buffer = reader.read(header_size)
    rank, dim1Len, dim2Len = struct.unpack('iii', header_buffer)
    if rank != 1:
        rank = dim2Len

    def read_one_dim():
        result = []
        for i in range(dim1Len):
            str_length_size = struct.calcsize('i')
            str_length_buffer = reader.read(str_length_size)
            str_length = struct.unpack('i', str_length_buffer)[0]
            str_buffer = reader.read(str_length)
            s = str_buffer.decode('utf-8')
            result.append(s)
        return result

    if rank == 1:
        return read_one_dim()
    else:
        result = []
        for j in range(dim2Len):
            result.append(read_one_dim())
        return result


def from_bytes_array(buffer, fmt_char):
    header_size = struct.calcsize('iii')
    header_buffer = buffer[:header_size]
    rank, dim1Len, dim2Len = struct.unpack('iii', header_buffer)
    buffer_start_pos = header_size
    if rank != 1:
        rank = dim2Len
    result = []
    for i in range(rank):
        fmt = fmt_char * dim1Len
        dim_buffer_size = struct.calcsize(fmt)
        buffer_end_pos = buffer_start_pos + dim_buffer_size
        dim_buffer = buffer[buffer_start_pos:buffer_end_pos]
        dim_data = struct.unpack(fmt, dim_buffer)
        buffer_start_pos = buffer_end_pos
        result.append(list(dim_data))
    if rank == 1:
        return result[0]
    return result


# 为了减少传输数据，加快protobuf编码解码速度
# 传输的quality = 原quality * 10000 + datatype
def decode_quality(qualityCode):
    datatype = qualityCode % 10000
    quality = (qualityCode - datatype) / 10000
    return quality, datatype


class OPCGateException(Exception):
    pass
