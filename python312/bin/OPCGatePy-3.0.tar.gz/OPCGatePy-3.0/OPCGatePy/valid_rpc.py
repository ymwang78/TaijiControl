# -*- coding: utf-8 -*-

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC


class ValidRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(ValidRPC, self).__init__(connector, manager,logger)
        self.call = 'Valid'

    def _create_request(self, *args, **kwargs):
        req = opc_pb2.ValidRequest(
            tag=kwargs.get('name')
        )
        return req

    def _handle_result(self, result):
        return result.valid
