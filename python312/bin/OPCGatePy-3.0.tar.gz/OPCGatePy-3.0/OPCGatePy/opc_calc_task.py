# -*- coding: utf-8 -*-
import threading
import time
import traceback
from OPCGatePy.gate_client import OPCGateClient

# OPC计算任务基类，所有的OPC计算都必须继承该类
# 子类需要实现两个方法：
#   run  开始任务
#   stop    停止任务
class OPCCalcTask(OPCGateClient):
    def __init__(self, ip, port):
        super(OPCCalcTask, self).__init__(ip, port)

        self.__pauseing = threading.Event()  # 用于暂停线程的标识
        self.__pauseing.set()
        self.__running = threading.Event()  # 用于停止线程的标识
        self.__running.set()  # 将running设置为True

        self.__time_out_when_stop = False
        self.__done_count = 0
        self.__time_out_count = 0
        self.__runing_status = "init"
        self.__sampling_time = 1


    def run(self):
        while self.__running.isSet():
            self.__pauseing.wait()
            start = time.time()
            try:
                self.done()
                self.__done_count += 1
            except:
                self.error(f"任务运行错误{ traceback.format_exc() }")
            end = time.time()
            last = self.__sampling_time - (end - start)
            if last and last > 0:
                time.sleep(last)
            else:
                self.info("任务运行超时 %s 秒" % (0-last))
                self.__time_out_count += 1
                if self.__time_out_when_stop:
                    self.stop()

    # 停止执行任务
    def stop(self):
        self.__runing_status = "stop"
        self.__running.clear()  # 设置为False
        self.info("任务【%s】已停止运行" % self.title())

    def set_time_out_stop(self):
        self.__time_out_when_stop = True

    #设置任务循环间隔时间（秒），默认1秒
    def set_sampling_time(self, sec):
        self.__sampling_time = sec

    # 设置任务循环间隔时间（秒），默认1秒
    def get_sampling_time(self):
        return self.__sampling_time

    def done(self):
        pass

    def get_done_count(self):
        return self.__done_count

    def get_time_out_count(self):
        return self.__time_out_count
