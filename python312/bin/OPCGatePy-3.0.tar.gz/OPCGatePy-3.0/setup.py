# coding=utf8

from setuptools import setup
from setuptools import find_packages

print(find_packages())
import time
print(time.time())
setup(
    name="OPCGatePy",
    version=3.0,
    author="xuyb",
    author_email="",
    description="OPCGate的Python Client接口包",
    keywords="OPCGate Python Client",
    packages=find_packages(),
    # setup_requires="" 指定安装的依赖，同样可以使用pip freeze > requirements.txt 生成依赖
    dependency_links=[],  # 添加依赖链接
    install_requires=[
        "grpcio",
        "protobuf"
    ]
)