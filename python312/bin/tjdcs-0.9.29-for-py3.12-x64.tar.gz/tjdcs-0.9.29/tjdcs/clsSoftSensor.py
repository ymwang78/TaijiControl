# import sys
# import os
# sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


from tjdcs.algorithm import tjSoftSensor

class SoftSensorBiasUpdate(tjSoftSensor.SoftSensorBiasUpdate):
    r'''
    软测量的偏差校正。
    计算预测值(prd_data)与化验值(lab_data)的偏差。
    '''
    def __init__(self, name: str = 'SoftSensor', filter_tao: float = 5, abs_threshold: float = 1e-6, prd_len: int = 28800, const_len: int = 60) -> None:
        r'''
        parameters
        ----------
        name: str, name of the soft sensor
        filter_tao: the returned bias is filtered by a one order filter which is denoted as 1/(filter_tao*s+1)
            the time unit is sample
            if filter_tao is zero, return the bias immediately
        abs_threshold (float 1e-6 - inf): the bias renew only when abs(prd_data-lab_data)>=abs_threshold
            otherwise the bias is hold (remain as the last return). 
        prd_len: length of the storage of prd_data list
        const_len (int >=0 ): bias update won't take active unless lab_data remain const for const_len
            if const_len is zero, bias update will take active immediately.
            the time unit is sample
        '''
        return super().__init__(name, filter_tao, abs_threshold, prd_len, const_len)
    
    def get_name(self) -> str:      
        r'''
        return the name of the soft sensor
        '''
        return super().get_name()
    
    def get_update_flag(self) -> bool:
        r'''
        return the flag of bias update
        '''
        return super().get_update_flag()
    
    def get_bias(self) -> float:
        r'''
        return the bias
        '''
        return super().get_bias()
    
    def get_lab_data(self) -> float:
        r'''
        return the lab_data
        '''
        return super().get_lab_data()
    
    def get_lab_time(self) -> float:
        r'''
        return the lab_time
        '''
        return super().get_lab_time()
    
    def get_prd_data_at_labtime(self) -> float:
        r'''
        return the prd_data at lab_time
        '''
        return super().get_prd_data_at_labtime()

    def run(self, prd_data: float, lab_data: float, lab_time: float, prd_time: float = None) -> float:
        r'''
        软测量的偏差校正。
        此函数应该在每个采样时刻运行，计算预测值(prd_data)与化验值(lab_data)的偏差。
        将偏差返回值加入到预测值中，即可得到校正后的预测值。
        在初始化时可设置滤波系数、化验值保持自定义时长后更新。        

        parameters
        ----------
        prd_data: float, predict data, usually is the data that the soft sensor predict.
        lab_data: float, usually is the analysis data from the laboratory.
        lab_time: float, usually is the time that the laboratory gets the sample.
        prd_time: optional, float, predict time, usually is the time that the soft sensor predict the prd_data
            if prd_time is None, use time.time() instead.
        
        returns
        -------
        filtered bias

        Notes
        -----
        lab_time and prd_time should at the same time measured system
        '''
        return super().run(prd_data, lab_data, lab_time, prd_time)


if __name__ == '__main__':
    import time
    import numpy as np
    bs_obj = SoftSensorBiasUpdate(name = 'SoftSensorTest', const_len=3, filter_tao=5)

    lab_value = 0
    lab_time = 0
    for k in range(0,10):
        prd_value = 0.2
        prd_time = float(k)
        if k == 5:
            lab_value = 6.0
        lab_time = k
        print(f"{k = }, {prd_value = }, {prd_time = }, {lab_value = }, {lab_time = }")
        bias = bs_obj.run(prd_value, lab_data=lab_value, lab_time = lab_time, prd_time=prd_time)
        if bs_obj.get_update_flag():
            print(f"New bias is updated.")
            print(f"{bs_obj.get_bias() = }")
            print(f"{bs_obj.get_lab_data() = }")
            print(f"{bs_obj.get_lab_time() = }")
            print(f"{bs_obj.get_prd_data_at_labtime() = }")
        
        print(f"fixed_prd = {prd_value + bias}, {bias = }, {bs_obj.get_update_flag() = }")
        time.sleep(0.3)