from .clsSFilter import sFilter
from .clsZFilter import zFilter
from .clsSoftSensor import SoftSensorBiasUpdate

from .clsInterface import ConstDect
from .clsInterface import RateLimit
from .clsInterface import WatchDog
from .clsInterface import TJProcSim, SimBase, TJOpcGateSimTask, TJProcSim2
from .clsInterface import LPVPlantSim
from .clsInterface import Model, SISO_tfs_Model
from .clsInterface import TestSignalGen
from .clsInterface import MIMOSim2
from .clsPID import PID

from .funInterface import current_time_str, dict2pairs, pair2dict, str2xpyp, c2d
from .funInterface import get_ModelDict_tags, tf2stp, stp2ipr, stp_stable_len, plot_model_stp

from .clsSimulink import Simulink
from .clsSimulinkOPCGateTask import SimulinkOPCGateTask


__version__ = '0.9.25'

##################################
# __version__ = '0.9.24'
# 2023-10
# 1. 调整了代码结构
# 2. 增加一些注释
#
#
# __version__ = '0.9.23'
# 2023-10
# 1. 增加了SoftSensorBiasUpdate功能
# 2. 修改了ZFilter和SFilter
# 3. 为一些代码增加了注释
#
#
# __version__ = '0.9.22'
# 2023-7-15
# 1. 修改了Simulink框架, 将done, one_sample_simulation统一为task
#
#
# __version__ = '0.9.15'
# 2022-12-29
# 1. 新增LPVPlantSim类
#
#
# __version__ = '0.9.14'
# 2022-11-21
# 1. 新增了MIMOSim2类，通过scipy中的lfilter进行被控对象仿真
#
#
# __version__ = '0.9.13'
# 2022-09-13
# 1. 修改了测试信号模块
#
#
# __version__ = '0.9.12'
# 2022-05-27
# 1. 修改了PID模块
#
#
# __version__ = '0.9.11'
# 2022-04-16
# 1. 修改了PID模块
#
#
# __version__ = '0.9.10'
# 2022-04-02
# 1. 修改了PID模块
#
#
# __version__ = '0.9.9'
# 2022-03-31
# 1. 修改了PID模块
# 2. 将Simulink类建立独立文件clsSimulink.py
#
# __version__ = '0.9.8'
# 2022-03-28
# 1. 新增Simulink仿真框架
#
# __version__ = '0.9.7'
# 2022-01-05
# 1. 修正了ProcessSim中的名称显示
#
# __version__ = '0.9.6'
# 2021-12-31
# 1. 添加授权文件
#
# __version__ = '0.9.5'
# 2021-12-31
# 1. 修改了TJProcSim
# 2. 重新设计了接口
#
# __version__ = '0.9.4'
# 2021-12-21
# 修改了TJProcSim
#
# __version__ = '0.9.3'
# 2021-11-16
# 增加积分模型
#
##################################