from .algorithm import tjConstDetector
from .algorithm import tjRateLimit
from .algorithm import tjWatchDog
from .algorithm import tjProcessModel
from .algorithm import tjProcessSim
from .algorithm import tjTestSignal
from .algorithm import MIMOSim2
from .algorithm import tjLPVPlant




class Model(tjProcessModel.Model):
    '''
    yu_model_tf的demo:
    yu_model_tf = {'CV1': {'MV1': {'mode': 'tf_s', 'num_s': [0, 1], 'den_s': [20, 1], 'iodelay_s': 2},
                          'MV2': {'mode': 'stp', 'stp': [0,0,1,1,0,0,4,4,4,7,8,9,4,3,3,3,4,5,4,3,3,3,3]}},
                   'CV2': {'MV1': {'mode': 'tf_z', 'num_z': [-0.02], 'den_z': [1, -0.95],     'iodelay_z': 5},
                           'DV1': {'mode': 'stpfx', 'x': [0, 10, 100, 350, 400, 600],  'y': [0, 0, 3, 9, 7, 7]},
                           'MV2': {'mode': 'None'}}}

    yu_model_tf = { 'S1.CV1': {'S1.MV1': {'mode': 'tf_z', 'num_z': [0, 1.0, 0.5], 'den_z': [1.0, -1.5, 0.7], 'iodelay_z': 0}}}
    '''
    def __init__(self, yu_model_tf, Ts=1) -> None:
        super().__init__(yu_model_tf, Ts=Ts)

    def update(self, yu_model_tf_SUB):
        return super().update(yu_model_tf_SUB)

    def get_model_tags(self, mode='list'):
        return super().get_model_tags(mode=mode)

class SimBase(tjProcessSim.SimBase):
    '''
    Future warning: 后续版本不再维护，改用Simulink框架。
    '''
    def __init__(self, *args, **kargs) -> None:
        super().__init__(*args, **kargs)

    def one_sample_simulation(self, u_Value_Dict: dict, *args, **kargs) -> dict:
        return super().one_sample_simulation(u_Value_Dict, *args, **kargs)

    def get_all_tags(self, *args, **kargs) -> list:
        return super().get_all_tags(*args, **kargs)

    def get_input_data_dict(self, *args, **kargs) -> dict:
        return super().get_input_data_dict(*args, **kargs)

    def get_output_data_dict(self, *args, **kargs) -> dict:
        return super().get_output_data_dict(*args, **kargs)

class TJOpcGateSimTask(tjProcessSim.TJOpcGateSimTask):
    '''
    Future warning: 后续版本不再维护，改用Simulink框架。
    '''
    def __init__(self, ip, port, Simobj: SimBase, tag_extension_dict: dict = {}, Name: str = 'SimTest'):
        super().__init__(ip, port, Simobj, tag_extension_dict=tag_extension_dict, Name = Name)

class TJProcSim(tjProcessSim.TJProcSim):
    def __init__(self, model: Model, ini_Value_Dict: dict = {}) -> None:
        super().__init__(model, ini_Value_Dict=ini_Value_Dict)

    def __call__(self, u_Value_Dict={}, v_Value_Dict={}) -> None:
        return super().__call__(u_Value_Dict=u_Value_Dict, v_Value_Dict=v_Value_Dict)

    def run(self, u_Value_Dict={}, v_Value_Dict={}) -> dict:
        super().__call__(u_Value_Dict=u_Value_Dict, v_Value_Dict=v_Value_Dict)
        return self.get_output_data_dict()

    def reset(self):
        return super().reset()

    def get_process_tags(self):
        return super().get_process_tags()

    def get_output_data_dict(self):
        return super().get_output_data_dict()

    def get_input_data_dict(self):
        return super().get_input_data_dict()

    def get_all_data_dict(self):
        return super().get_all_data_dict()

    def update_process_model(self, *args):
        return super().update_process_model(*args)

class TJProcSim2(MIMOSim2.TJProcSim2):
    def __init__(self, process_model_dict: dict, ini_value_dict: dict={}, Ts=1) -> None:
        super().__init__(process_model_dict, ini_value_dict, Ts)

    def __call__(self, u_Value_Dict={}, v_Value_Dict={}) -> dict:
        return super().__call__(u_Value_Dict=u_Value_Dict, v_Value_Dict=v_Value_Dict)

    def run(self, u_Value_Dict={}, v_Value_Dict={}) -> dict:
        return super().__call__(u_Value_Dict=u_Value_Dict, v_Value_Dict=v_Value_Dict)

    def reset(self):
        return super().reset()

    def get_process_tags(self):
        return super().get_process_tags()

    def get_output_data_dict(self):
        return super().get_output_data_dict()

    def get_input_data_dict(self):
        return super().get_input_data_dict()

    def get_all_data_dict(self):
        return super().get_all_data_dict()

    # def update_process_model(self, *args):
    #     return super().update_process_model(*args)


class LPVPlantSim(tjLPVPlant.LPVPlantSim):

    def __init__(self, ini_value_dict=...) -> None:
        super().__init__(ini_value_dict)

    def addPlant(self, plant_id: int, operating_point: float, yu_model_tf: dict, Ts: int) -> None:
        return super().addPlant(plant_id, operating_point, yu_model_tf, Ts)

    def delPlant(self, plant_id: int) -> None:
        return super().delPlant(plant_id)

    def run(self, operating_value: float, u_Value_Dict=..., v_Value_Dict=...) -> dict:
        return super().run(operating_value, u_Value_Dict, v_Value_Dict)

    def get_plant_dict(self):
        return super().get_plant_dict()

    def get_current_plant_weight_dict(self):
        return super().get_current_plant_weight_dict()


class SISO_tfs_Model(tjProcessModel.SISO_tfs_Model):
    def __init__(self, gain, tao, delay, Ts=1) -> None:
        super().__init__(gain, tao, delay, Ts=Ts)

    def update(self, gain, tao, delay):
        return super().update(gain, tao, delay)


class WatchDog(tjWatchDog.WatchDog):
    '''
    看门狗，输出按调用次数自增循环。
    '''
    def __init__(self) -> None:
        super().__init__()

    def __call__(self, MaxOut=0) -> int:
        return super().__call__(MaxOut=MaxOut)


class RateLimit(tjRateLimit.RateLimit):
    def __init__(self, u_ini: float, Ts=1):
        super().__init__(u_ini, Ts=Ts)

    def __call__(self, u_end, PRLimPerMin=60, NRLimPerMin=None):
        return super().__call__(u_end, PRLimPerMin=PRLimPerMin, NRLimPerMin=NRLimPerMin)


class ConstDect(tjConstDetector.ConstDect):
    def __init__(self) -> None:
        super().__init__()

    def run(self, Ut, DectLen=10) -> bool:
        return super().__call__(Ut, DectLen=DectLen)
    
    def __call__(self, Ut, DectLen=10) -> bool:
        return super().__call__(Ut, DectLen=DectLen)


class TestSignalGen(tjTestSignal.TestSignal):
    def __init__(self, SEED=None):
        super().__init__(SEED)

    def set_ET(self, ET=10):
        return super().set_ET(ET)

    def get_ET(self):
        return super().get_ET()

    def set_amplitude(self, amp=1):
        return super().set_amplitude(amp)

    def get_amplitude(self):
        return super().get_amplitude()

    def __call__(self, t=None):
        return super().__call__(t)

    def run(self, t = None):
        return super().__call__(t)
