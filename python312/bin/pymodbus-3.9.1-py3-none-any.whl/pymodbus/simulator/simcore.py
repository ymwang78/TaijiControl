"""Simulator data model classes."""
from __future__ import annotations


class SimCore:  # pylint: disable=too-few-public-methods
    """Datastore for the simulator/server."""
