def find_project_path(matker:str = '.git') -> str:
    from pathlib import Path
    if '__file__' in globals():
        current_path = Path(__file__).resolve()
    else:
        current_path = Path().resolve()
    project_root = current_path
    while not (project_root / matker).exists():
        project_root = project_root.parent
        if project_root == project_root.parent:
            raise ValueError("Reached the root of the file system without finding the marker.")
    return str(project_root)

prj_path = find_project_path(matker='setup.py')
print(f"{prj_path = }")
import sys
sys.path.insert(0, prj_path)