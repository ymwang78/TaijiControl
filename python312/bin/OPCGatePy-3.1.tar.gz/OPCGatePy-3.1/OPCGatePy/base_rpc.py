# -*- coding: utf-8 -*-
import logging

from google.protobuf.struct_pb2 import Value, ListValue

from OPCGatePy import opc_pb2
from OPCGatePy.grpc_connector import OPCGateGrpcConnector
from OPCGatePy.tag_manager import TagManager
import grpc
import threading,time

from OPCGatePy.utils import create_metadata


class BaseRPC:
    def __init__(self, connector: OPCGateGrpcConnector, manager: TagManager, logger: logging.Logger):
        self.connector = connector
        self.manager = manager
        self.logger = logger
        self.call = ''
        self.threadId = threading.current_thread().ident

    def _create_request(self, *args, **kwargs):
        raise NotImplementedError()

    def _handle_result(self, result):
        pass

    def _handle_exception(self, e: Exception):
        pass

    def _call_rpc(self, *args, **kwargs):
        #print(self.threadId)
        s = time.time()
        if not self.call:
            raise Exception("must set self.call")

        req = self._create_request(*args, **kwargs)
        try:
            server = kwargs.get("server")
            if server:
                stub = self.connector.get_stub_by_server(server)
                rets, call = self.connector.get_call(self.call, stub).with_call(req, metadata=create_metadata())
                return self._handle_result(rets)
            else:
                # pass
                rets, call = self.connector.get_call(self.call).with_call(req, metadata=create_metadata())
                trailing_metadata = call.trailing_metadata()
                if len(trailing_metadata) > 0:
                    rs = float(call.trailing_metadata()[0][1])
                #print(time.time()-rs)
                return self._handle_result(rets)
        except grpc.RpcError as e:
            self.logger.error("与OPC服务器通讯错误，请确保服务器已开启")
            self._handle_exception(e)
        except Exception as e:
            self.logger.error("【%s】向OPC服务器读写数据失败" % self.call)
            self._handle_exception(e)
        finally:
            pass
            #print(time.time() - s)

    def _build_value(self, v):
        if type(v) == bool:
            val = Value(bool_value=v)
        elif type(v) == str:
            val = Value(string_value=v)
        elif v is None:
            val = Value(null_value=v)
        elif type(v) == list or type(v) == tuple:
            if len(v) == 0:
                self.logger.error("空List类型无法写入")
                return None
            ret = []
            for o in v:
                ret.append(self._build_value(o))
            val = Value(list_value=ListValue(values=ret))
        else:
            val = Value(number_value=v)
        return val

    def _create_value(self, ret):
        t = type(ret)
        if t != opc_pb2.Tag and t != ListValue:
            return ret
        if t == ListValue:
            val = []
            for v in ret:
                val.append(self._create_value(v))
            return val
        if ret.value.HasField('number_value'):
            val = ret.value.number_value
        elif ret.value.HasField('bool_value'):
            val = ret.value.bool_value
        elif ret.value.HasField('string_value'):
            val = ret.value.string_value
        elif ret.value.HasField('null_value'):
            val = 0
        elif ret.value.HasField('list_value'):
            lst = ret.value.list_value
            val = []
            for v in lst:
                val.append(self._create_value(v))
        return val

    def __call__(self, *args, **kwargs):
        return self._call_rpc(*args, **kwargs)

