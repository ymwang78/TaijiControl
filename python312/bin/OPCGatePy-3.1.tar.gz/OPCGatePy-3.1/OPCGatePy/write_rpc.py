# -*- coding: utf-8 -*-

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC


def dict_to_key_and_val_list(dict):
    names = []
    vals = []
    for k, v in dict.items():
        names.append(k)
        vals.append(v)
    return names, vals


class WriteRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(WriteRPC, self).__init__(connector, manager, logger)
        self.call = 'Write'

    def _create_request(self, *args, **kwargs):
        tag_value_pairs = kwargs.get("tags")
        is_create = kwargs.get("create")

        '''
        def remap(item):
            val = self._build_value(item[1])
            return item[0], val

        tags = dict(map(remap, tag_value_pairs.items()))
        '''
        names = []
        vals = []
        for k, v in tag_value_pairs.items():
            names.append(k)
            val = self._build_value(v)
            vals.append(val)

        req = opc_pb2.WriteRequest(
            tags=names,
            vals=vals,
            create=is_create
        )
        return req


class WriteNumberRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(WriteNumberRPC, self).__init__(connector, manager, logger)
        self.call = 'WriteNumber'

    def _create_request(self, *args, **kwargs):
        tag_value_pairs = kwargs.get("tags")
        is_create = kwargs.get("create")
        names, vals = dict_to_key_and_val_list(tag_value_pairs)
        req = opc_pb2.WriteNumberRequest(
            tags=names,
            vals=vals,
            create=is_create
        )
        return req


class WriteBooleanRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(WriteBooleanRPC, self).__init__(connector, manager, logger)
        self.call = 'WriteBoolean'

    def _create_request(self, *args, **kwargs):
        tag_value_pairs = kwargs.get("tags")
        is_create = kwargs.get("create")
        names, vals = dict_to_key_and_val_list(tag_value_pairs)
        req = opc_pb2.WriteBooleanRequest(
            tags=names,
            vals=vals,
            create=is_create
        )
        return req


class WriteStringRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(WriteStringRPC, self).__init__(connector, manager, logger)
        self.call = 'WriteString'

    def _create_request(self, *args, **kwargs):
        tag_value_pairs = kwargs.get("tags")
        is_create = kwargs.get("create")
        names, vals = dict_to_key_and_val_list(tag_value_pairs)
        req = opc_pb2.WriteStringRequest(
            tags=names,
            vals=vals,
            create=is_create
        )
        return req
