# -*- coding: utf-8 -*-
import grpc

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC
from OPCGatePy.utils import from_bytes, DataType, decode_quality
import time


class ReadRPC(BaseRPC):
    def __init__(self, connector, manager,logger):
        super(ReadRPC, self).__init__(connector, manager,logger)
        self.call = 'Read'
        self.tags = []
        self.start = 0
        self.length = 0

    def _create_request(self, *args, **kwargs):
        tags = kwargs.get('tags')
        start = kwargs.get('start')
        length = kwargs.get('length')
        if type(tags) == tuple:
            tags = [t for t in tags]
        elif type(tags) == str:
            tags = [tags]
        self.tags = tags
        self.start = start
        self.length = length

        # 暂时只用位号名
        names = tags
        ids = None

        '''
        if start == 0 and length == 0:
            for tag in tags:
                id = self.manager.get_tag_id(tag)
                if id:
                    ids.append(id)
                else:
                    names.append(tag)
        else:
            # 暂时取缓存只能用位号名
            names = tags
        '''

        req = opc_pb2.ReadRequest(
            names=names,
            ids=ids,
            duration=start,
            length=length
        )
        return req

    def _handle_result(self, result):
        results = []
        rets = self._build_tag_result(result)
        for ret in rets:
            results.append(ret)
        return results

    def _build_tag_result(self, result):
        index = 0
        length = self.length
        if length == 0:
            length = abs(self.start)
        if length == 0:
            length = 1
        for name in self.tags:
            if length == 1:
                ret = self.__build_tag_result(index, name, result)
                index += 1
                yield ret
            else:
                for i in range(length):
                    ret = self.__build_tag_result(index, name, result)
                    index += 1
                    yield ret

    def __build_tag_result(self, index, name, result):
        qualityCode = result.quality[index]
        qualityCode, datatype = decode_quality(qualityCode)
        value = result.value[index]
        val = from_bytes(datatype, value)
        quality = 'Bad'
        if qualityCode == 4:  # badConfigurationError,表示位号已经不存在了
            pass
        if qualityCode == 192:
            quality = 'Good'
        ret = (name, val, quality, time.time())
        if self.start == 0:
            self.manager.add_to_cache(ret)
        return ret

    def _handle_exception(self, e: Exception):
        quality = 'RPCFail'
        if e is grpc.RpcError:
            quality = 'RPCError'
        results = []
        for tag in self.tags:
            val = self.manager.read_last_cache_value(tag)
            if not val:
                ret = (tag, None, quality, time.time())
            else:
                ret = (val[0], val[1], quality, time.time())
            results.append(ret)
        return results
