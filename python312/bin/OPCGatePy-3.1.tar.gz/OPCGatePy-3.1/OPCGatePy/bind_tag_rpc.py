# -*- coding: utf-8 -*-

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC


class BindTagRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(BindTagRPC, self).__init__(connector, manager,logger)
        self.call = 'BindTagsId'

    def _create_request(self, *args, **kwargs):
        req = opc_pb2.BindRequest(
            tags=kwargs.get('tags')
        )
        return req

    def _handle_result(self, result):
        for name, id in result.bindTags.items():
            # id == 0 表示该位号不存在
            if id != 0:
                self.manager.add_tag(name, id)

