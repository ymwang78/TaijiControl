# -*- coding: utf-8 -*-


class TagManager:
    def __init__(self):
        self.map_tag_name2Id = {}
        self.map_tag_Id2name = {}
        self.__cache = {}
        self.__cache_length = 1
        self.__sub_tags_cache = {}  # 订阅位号数据缓存

    def is_tag_binding(self, name):
        return name in self.map_tag_name2Id

    def get_tag_id(self, name):
        return self.map_tag_name2Id.get(name)

    def get_tag_name(self, id):
        return self.map_tag_Id2name.get(id)

    def add_tag(self, name, id):
        self.map_tag_name2Id[name] = id
        self.map_tag_Id2name[id] = name

    def add_to_cache(self, ret):
        tag = ret[0]
        if self.__cache_length == 1:
            self.__cache[tag] = [ret]
        else:
            if tag not in self.__cache:
                self.__cache[tag] = []
            self.__cache[tag].append(ret)
            if len(self.__cache[tag]) > self.__cache_length:
                self.__cache[tag] = self.__cache[tag][1:]

    def read_from_cache(self, tags, start, length):
        results = []
        for tag in tags:
            if tag not in self.__cache:
                self.__cache[tag] = []
            results.extend(self.__cache[tag][start:start + length])
        return results

    def read_last_cache_value(self, tag):
        if tag not in self.__cache:
            return None
        length = len(self.__cache[tag])
        return self.__cache[tag][length - 1]

    def update_sub_tags_cache(self, dict):
        self.__sub_tags_cache.update(dict)

    def enum_sub_tags_cache(self):
        for name in self.__sub_tags_cache:
            yield self.__sub_tags_cache.get(name)

    def get_sub_tag(self, name):
        return self.__sub_tags_cache.get(name)

    def sub_tags_count(self):
        return len(self.__sub_tags_cache)
