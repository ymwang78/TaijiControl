import inspect
import time
from OPCGatePy.opc_calc_task import OPCCalcTask   


class OPCItem:
    '''
    OPC item class, used to store OPC item information.
    Each OPC item has a tag, description, time shift, initial value, and limits.
    '''
    def __init__(self, tag: str, 
                 description: str='', 
                 prefix: str='', 
                 ini_value: float=float('nan'),
                 time_shift: int=0, 
                 lo_limit: float=float('-inf'), 
                 hi_limit: float=float('inf')):
        self.tag = f"{prefix}.{tag}" if prefix else tag
        self.description = description
        self.time_shift = time_shift  # in seconds
        self.value = ini_value
        self.last_good_value = ini_value
        self.lo_limit = lo_limit
        self.hi_limit = hi_limit

    def __str__(self):
        return 'Tag: %s, Description: %s, TimeShift: %d, Value: %f, LOLimit: %f, HILimit: %f' % (
            self.tag, self.description, self.time_shift, self.value, self.lo_limit, self.hi_limit
        )
        

def find_opc_items(prefix_str: str = ''):
    # Automatically retrieve the global scope of the caller of this function
    frame = inspect.currentframe()
    caller_frame = frame.f_back
    caller_globals = caller_frame.f_globals

    opc_items = []
    for name, obj in caller_globals.items():
        if isinstance(obj, OPCItem) and obj.tag.startswith(prefix_str):
            opc_items.append(obj)
    return opc_items


class OPCCalcTask2(OPCCalcTask):
    '''
    OPC calculation task base class, all OPC calculations must inherit this class
    '''
    def __init__(self, ip: str='localhost', port: int=9999):
        super().__init__(ip, port)
    
    
    def read_OPC(self, opc_read_list: list[OPCItem] = None):
        if not opc_read_list:
            return

        def update_item(item: OPCItem, value_tuple):
            _name, _value, _quality, _timestamp = value_tuple
            if _quality == 'Good' and item.lo_limit <= _value <= item.hi_limit:
                item.value = _value
                item.last_good_value = _value
            else:
                item.value = item.last_good_value

        now_items = [item for item in opc_read_list if item.time_shift == 0]
        shift_items = [item for item in opc_read_list if item.time_shift != 0]

        # Current value reading (batch)
        if now_items:
            try:
                results = self.read([item.tag for item in now_items])
            except Exception as e:
                print(f"Current value read failed: {e}")
                results = None
            if results:
                for item, value in zip(now_items, results):
                    update_item(item, value)
            else:
                for item in now_items:
                    item.value = item.last_good_value

        # Historical value reading (item by item)
        for item in shift_items:
            try:
                result = self.read(item.tag, start=-abs(item.time_shift), length=1)
            except Exception as e:
                print(f"[{item.tag}] Historical read failed: {e}")
                result = None
            if result:
                update_item(item, result[0])
            else:
                item.value = item.last_good_value
            
            
    def write_OPC(self, opc_write_list: list[OPCItem]):
        d = {}
        for item in opc_write_list:
            if item.tag and item.lo_limit <= item.value <= item.hi_limit:
               d[item.tag] = item.value
        if d:
            self.write(d)
            
            
    def create_local_tags(self, opc_list: list[OPCItem]):
        d = {item.tag: item.value for item in opc_list if isinstance(item, OPCItem)}
        self.write_and_create(d)
        time.sleep(1)