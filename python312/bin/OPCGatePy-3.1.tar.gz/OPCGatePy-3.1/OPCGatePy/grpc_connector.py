# -*- coding: utf-8 -*-
import time
import logging
import grpc
from OPCGatePy import opc_pb2_grpc
import threading

from OPCGatePy.utils import create_metadata, OPCGateException
from OPCGatePy.tag_manager import TagManager
from OPCGatePy.subscribe_rpc import SubscribeRPC

# 负责Grpc通讯
class OPCGateGrpcConnector:
    def __init__(self, ip, port, manager: TagManager, logger: logging.Logger):
        self.__channel = grpc.insecure_channel('%s:%s' % (ip, port))
        self.__channel.subscribe(self.__callback, True)
        self.stub = opc_pb2_grpc.OPCStub(self.__channel)
        self.__stubs = {}
        self.__subscribers = {}  # 订阅Client
        self.__lock = threading.Lock()  # 线程同步锁
        self.__connectivityState = grpc.ChannelConnectivity.IDLE
        self.__logger = logger
        self.__manager = manager

    def __callback(self, state):
        if self.__connectivityState == grpc.ChannelConnectivity.READY \
                and state != grpc.ChannelConnectivity.READY:
            self.__UnSubscribeAll(True)
        self.__connectivityState = state

    # 取消指定订阅
    # 订阅的取消分两种，主动取消和被动取消
    # 一般来讲，主动取消是调用订阅者由于订阅完成或变更订阅而取消，
    #         该类取消需要删除已经存在的订阅器，订阅器不需要再重连，所以reconnected=False
    #         被动取消主要是由于网络或服务端掉线，所有该类订阅需要重连已完成后续订阅，reconnected=True
    def __UnSubscribe(self, name="Default", reconnected=True):
        self.__lock.acquire()
        subscriber = self.__subscribers.get(name)
        if subscriber:
            #subscriber.cancel()
            subscriber.UnSubscribe()
            if not reconnected:
                del self.__subscribers[name]
        self.__lock.release()

    # 取消所有订阅
    # 订阅的取消分两种，主动取消和被动取消
    # 一般来讲，主动取消是调用订阅者由于订阅完成或变更订阅而取消，
    #         该类取消需要删除已经存在的订阅器，订阅器不需要再重连，所以reconnected=False
    #         被动取消主要是由于网络或服务端掉线，所有该类订阅需要重连已完成后续订阅，reconnected=True
    def __UnSubscribeAll(self, reconnected=True):
        self.__lock.acquire()
        for name in self.__subscribers:
            self.__subscribers[name].UnSubscribe()
        if not reconnected:
            self.__subscribers.clear()
        self.__lock.release()

    def get_stub_by_server(self, server):
        if server in self.__stubs:
            return self.__stubs.get(server)
        else:
            channel = grpc.insecure_channel(server)
            stub = opc_pb2_grpc.OPCStub(channel)
            self.__stubs[server] = stub
            return stub

    def get_call(self, name, stub=None):
        if stub:
            return stub.__getattribute__(name)
        return self.stub.__getattribute__(name)

    def Subscribe(self, tags, name="Default", onlyValue=False):
        # 获取订阅器
        subscriber = self.__subscribers.get(name)
        if not subscriber:
            # 订阅器不存在，则创建订阅器
            rpc = SubscribeRPC(self, self.__manager, self.__logger)
            rets = rpc(tags=tags, onlyValue=onlyValue)
            self.__subscribers[name] = rpc
            if rets is not None:
                for ret in rets:
                    yield ret


            # 一般上面yield会阻塞，除非网络或服务器断线导致退出
            # 则取消当前订阅，标记该订阅需要重连
            self.__UnSubscribe(name, True)
        else:
            raise OPCGateException("Subscriber Name [%s] is exists" % name)

        # 重新获取订阅器，确保订阅器存在
        subscriber = self.__subscribers.get(name)

        # 循环检测订阅器，是否订阅器有效，无效则重连
        while subscriber and not subscriber.is_active():
            # rpc = SubscribeTestRPC(self, self.__manager, self.__logger)
            rets = subscriber.reconnect()
            if rets is not None:
                for ret in rets:
                    yield ret
            self.__UnSubscribe(name, True)
            time.sleep(1)

    def UnSubscribeAll(self):
        self.__UnSubscribeAll(False)

    def UnSubscribe(self, name="Default"):
        self.__UnSubscribe(name, False)

    def AddSubscribeTags(self, tags, name="Default"):
        subscriber = self.__subscribers.get(name)
        if subscriber:
            subscriber.add_tags(tags)

    def RemoveSubscribeTags(self, tags, name="Default"):
        subscriber = self.__subscribers.get(name)
        if subscriber:
            subscriber.remove_tags(tags)

    @property
    def connected(self):
        return self.__connectivityState == grpc.ChannelConnectivity.READY
