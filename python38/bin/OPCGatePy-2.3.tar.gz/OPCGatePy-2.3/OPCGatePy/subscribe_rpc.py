# -*- coding: utf-8 -*-
import time
from queue import Queue

import grpc

from OPCGatePy import opc_pb2
from OPCGatePy.utils import OPCGateException, from_bytes, decode_quality
from OPCGatePy.tag_manager import TagManager
from OPCGatePy.utils import create_metadata


class SubscribeRPC:
    def __init__(self, connector, manager: TagManager, logger):
        self.connector = connector
        self.manager = manager
        self.logger = logger
        self.call = 'Subscribe'
        self.onlyValue = False
        self.tags_queue = Queue()
        self.subscriber = None
        self.subscribe_tags = set()
        self.__MAX_REQ_TAGS = 2000

        self.reconnect_fail_tags = set()  # 记录重连失败的订阅位号

    def _create_request(self, *args, **kwargs):
        tags = kwargs.get('tags')
        self.onlyValue = kwargs.get("onlyValue")
        self.add_tags(tags)
        while True:
            tag = self.tags_queue.get()

            req = opc_pb2.SubscribeRequest(
                tags=tag[0],
                isRemove=tag[1]
            )
            yield req

    def _call_rpc(self, *args, **kwargs):
        if not self.call:
            raise Exception("must set self.call")
        req = self._create_request(*args, **kwargs)
        self.subscriber = self.connector.get_call(self.call)(req, metadata=create_metadata())
        return self._handle_result(self.subscriber)

    # 动态增加订阅位号
    def add_tags(self, tags):
        if type(tags) == tuple:
            tags = [t for t in tags]
        elif type(tags) == str:
            tags = [tags]
        diff = set(tags).difference(self.subscribe_tags)
        self.subscribe_tags = self.subscribe_tags.union(diff)
        #for t in diff:
        #    self.tags_queue.put((t, False))
        self.enqueue(diff, False)

    def remove_tags(self, tags):
        if type(tags) == tuple:
            tags = [t for t in tags]
        elif type(tags) == str:
            tags = [tags]
        for t in tags:
            self.subscribe_tags.discard(t)
        #for t in tags:
        #    self.tags_queue.put((t, True))
        self.enqueue(tags, True)

    def enqueue(self, tags, isRemove):
        tags = list(tags)

        count = len(tags)
        batchCount = count // self.__MAX_REQ_TAGS
        if count % self.__MAX_REQ_TAGS != 0:
            batchCount += 1
        for i in range(batchCount):
            batchTags = tags[i * self.__MAX_REQ_TAGS: (i + 1) * self.__MAX_REQ_TAGS]
            self.tags_queue.put((batchTags, False))

    # 断线重连，重新订阅
    def reconnect(self):
        # 断开连接时，订阅流未连接，所以每个订阅位号发送订阅请求时
        # 都会尝试连接，一旦连接成功，后续订阅位号就会重用第一个连接成功的订阅流
        # 重连将不再继续，所以第一个连接成功之前的订阅位号将不再加入到订阅流
        # 导致订阅位号丢失
        for t in self.subscribe_tags:
            self.tags_queue.put((t, False))
        return self.__call__(tags=[])

    def UnSubscribe(self):
        if self.subscriber:
            self.subscriber.cancel()

    def is_active(self):
        return self.subscriber and self.subscriber.is_active()

    def _handle_result(self, result):
        for r in result:
            #  有正常数据，表示连接成功
            #  判断重连失败列表是否为空，把列表中位号重新加入到订阅队列中
            if len(self.reconnect_fail_tags) > 0:
                print(self.reconnect_fail_tags)
                for t in self.reconnect_fail_tags:
                    self.tags_queue.put((t, False))
                self.reconnect_fail_tags.clear()

            name = r.name
            if not self.onlyValue:
                qualityCode = r.quality
                qualityCode, datatype = decode_quality(qualityCode)
                quality = 'Bad'
                if qualityCode == 192:
                    quality = 'Good'
                if qualityCode == 4:  # badConfigurationError,表示位号已经不存在了
                    pass
                # val = self._create_value(r)
                val = from_bytes(datatype, r.value)

                ret = (name, val, quality, time.time())
                self.manager.update_sub_tags_cache({name: ret})
                yield {name: ret}
            else:
                # val = self._create_value(r)
                val = from_bytes(r.datatype, r.value)
                yield {name: val}

    def _handle_exception(self, e, type):
        quality = 'RPCFail'   # 表示Grpc
        if type == 'RpcError':
            quality = 'RpcError'  # 表示RPC通讯错误
        if not self.onlyValue:
            for val in self.manager.enum_sub_tags_cache():
                if quality == 'RpcError':
                    # 连接失败，把位号加入到重连失败位号列表重
                    self.reconnect_fail_tags.add(val[0])
                ret = (val[0], val[1], quality, time.time())
                yield {val[0]: ret}

    def __call__(self, *args, **kwargs):
        try:
            rets = self._call_rpc(*args, **kwargs)
            for ret in rets:
                yield ret
        except grpc.RpcError as e:
            self.logger.error("与OPC服务器通讯错误，请确保服务器已开启")
            rets = self._handle_exception(e, 'RpcError')
            for ret in rets:
                yield ret
        except GeneratorExit:
            pass
        except OPCGateException as e:
            raise e
        except Exception as e:
            self.logger.error("向OPC服务器读写数据失败")
            rets = self._handle_exception(e)
            for ret in rets:
                yield ret
