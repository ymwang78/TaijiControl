# -*- coding: utf-8 -*-

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC


class EnumTagsRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(EnumTagsRPC, self).__init__(connector, manager,logger)
        self.call = 'GetAllTags'

    def _create_request(self, *args, **kwargs):
        req = opc_pb2.ListRequest(
            prefix=kwargs.get('prefix')
        )
        return req

    def _handle_result(self, result):
        return result.tags

    def _handle_exception(self, e: Exception):
        return []

