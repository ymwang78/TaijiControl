# -*- coding: utf-8 -*-

from OPCGatePy import opc_pb2
from OPCGatePy.base_rpc import BaseRPC


class CreateRPC(BaseRPC):
    def __init__(self, connector, manager, logger):
        super(CreateRPC, self).__init__(connector, manager, logger)
        self.call = 'Create'

    def _create_request(self, *args, **kwargs):
        ps = []
        tags = kwargs.get("tags")
        if type(tags) == tuple or type(tags) == list:
            for o in tags:
                p = opc_pb2.TagProperty(
                    dbindex=o['dbindex'],
                    name=o['name'],
                    desc=o['desc'],
                    cacheLen=o['cachelen'],
                    remark=o['remark'],
                    datatype=o['datatype'],
                    value=o['value']
                )
                ps.append(p)
        elif type(tags) == dict:
            o = tags
            p = opc_pb2.TagProperty(
                dbindex=o['dbindex'],
                name=o['name'],
                desc=o['desc'],
                cacheLen=o['cachelen'],
                remark=o['remark'],
                datatype=o['datatype'],
                value=o['value']

            )
            ps.append(p)
        else:
            raise Exception("数据类型不正确")
        req = opc_pb2.CreateRequest(
            propertys=ps
        )
        return req

    def _handle_result(self, result):
        for name, id in result.bindTags.items():
            # id == 0 表示位号不存在
            if id != 0:
                self.manager.add_tag(name, id)

