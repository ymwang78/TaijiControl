# coding=utf8

from setuptools import setup
from setuptools import find_packages

print(find_packages())
setup(
    name="PidMimoLib",
    version=1.5,
    author="xuyb",
    author_email="",
    description="PidMimo.dll的Python包装库",
    keywords="PidMimo Python Wrapper",
    packages=find_packages(),
    include_package_data=True,
    # setup_requires="" 指定安装的依赖，同样可以使用pip freeze > requirements.txt 生成依赖
    dependency_links=[],  # 添加依赖链接
    install_requires=[
        "numpy"
    ]
)