
import ctypes,os
import numpy as np


# 对libmx.dll 的包装类
class LibMX:
    def __init__(self):
        current_dir = os.path.dirname(__file__)
        file_path = os.path.join(current_dir, 'dll/libmx.dll')
        self.dll = ctypes.windll.LoadLibrary(file_path)

    # 把字符串转化为Matlab矩阵指针
    def str2mxArray(self, str):
        buf = ctypes.create_string_buffer(str.encode())
        return self.dll.mxCreateString(buf)

    # 把Matlab矩阵指针转化为字符串
    def mxArray2str(self, pointer):
        buf = ctypes.create_string_buffer(512)
        ret = self.dll.mxGetString(pointer, buf, 512)
        if ret == 0:
            return buf.value.decode()
        return ''

    # 把double转化为Matlab矩阵指针
    def double2mxArray(self, val):
        return self.towDimArray2mxArray([[val]])

    # 把Matlab矩阵指针转化为double
    def mxArray2double(self, pointer):
        arr = self.mxArray2SingleDimArray(pointer)
        return arr[0]

    # 把Matlab矩阵指针转化为一维数组
    def mxArray2SingleDimArray(self, pointer):
        row = self.dll.mxGetM(pointer)
        col = self.dll.mxGetN(pointer)
        num = row * col
        ret = self.dll.mxGetPr(pointer)
        buf = (ctypes.c_double * num)()
        ctypes.memmove(buf, ret, ctypes.sizeof(ctypes.c_double) * num)
        result = []
        for i in range(num):
            result.append(buf[i])
        return result

    # 把一维数组转化为Matlab矩阵指针
    def singleDimArray2mxArray(self, arr):
        return self.towDimArray2mxArray([arr])

    # 把二维数组转化为Matlab矩阵指针
    def towDimArray2mxArray(self, arr):
        x = np.array(arr)
        row, col = x.shape
        pointer = self.dll.mxCreateDoubleMatrix(row, col, 0)
        num = row * col
        buf = (ctypes.c_double * num)()
        data = x.flatten()
        for i in range(num):
            buf[i] = ctypes.c_double(data[i])
        self.dll.mxSetPr(pointer, ctypes.byref(buf))
        return self.dll.mxDuplicateArray(pointer)

    # 把Matlab矩阵指针转化为二维数组
    def mxArray2TwoDimArray(self, pointer):
        row = self.dll.mxGetM(pointer)
        col = self.dll.mxGetN(pointer)
        ret = self.mxArray2SingleDimArray(pointer)
        x = np.array(ret)
        result = x.reshape(row, col)
        return result
