
# dcs设备适配器
class ControllerAdapter:
    def __init__(self):
        self.adapters = {
            "ABB Bailey classical": self.Bailey_classical,
            "ABB Bailey non-int": self.Bailey_non_int,

            "DeltaV Series PID on E": self.DeltaV_Series_PID_on_E,
            "DeltaV Series PI on E, D on PV": self.DeltaV_Series_PID_on_E,
            "DeltaV Series I on E, PD on PV": self.DeltaV_Series_PID_on_E,
            "DeltaV Standard PID on E": self.DeltaV_Standard_PID_on_E,
            "DeltaV Standard PI on E, D on PV": self.DeltaV_Standard_PID_on_E,
            "DeltaV Standard I on E, PD on PV": self.DeltaV_Standard_PID_on_E,

            "Honeywell int A": self.Honeywell_int_A,
            "Honeywell int B": self.Honeywell_int_A,
            "Honeywell int C": self.Honeywell_int_A,
            "Honeywell non-int A": self.Honeywell_nonint_A,
            "Honeywell non-int B": self.Honeywell_nonint_A,
            "Honeywell non-int C": self.Honeywell_nonint_A,

            "Yokogawa Centum I-PD": self.Yokogawa_Centum_PID,
            "Yokogawa Centum PID": self.Yokogawa_Centum_PID,
            "Yokogawa Centum PI-D": self.Yokogawa_Centum_PID,

            "Siemens S7-200": self.Siemens_S7_200,

            "Foxboro int": self.Foxboro_int,
            "Foxboro non-int": self.Foxboro_non_int,

            "Supcon Standard": self.Supcon_Standard,
            "Supcon FW247": self.Supcon_FW247,
            "Supcon D On PV": self.Supcon_Standard,
            "Supcon ECS-700": self.Supcon_ECS700,

            "GuoDianZhiShen NT-Plus": self.GuoDianZhiShen_NT_PLUS,

            "Interacting A": self.Interacting_A,
            "Interacting B": self.Interacting_A,
            "Interacting C": self.Interacting_A,
            "Non-interacting A": self.Non_interacting_A,
            "Non-interacting B": self.Non_interacting_A,
            "Non-interacting C": self.Non_interacting_A,

            "Matlab Parallel(Discrete)": self.Matlab_Parallel,
            "Matlab Ideal(Discrete)": self.Matlab_Ideal,
        }

    def Bailey_classical(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'Kp',
            'iname': 'Ki',
            'dname': 'Kd',
        }
        if unit.lower().startswith('s'):
            i = i / 60
            d = d / 60
            unit = 'm'
        unit = ' %s' % unit
        i = 1 / i
        result['pv'] = '%.3f/K' % p
        result['iv'] = '%.3f %s [reset/min]' % (i, unit)
        if pidtype == 0:
            result['dv'] = '%.3f %s [min]' % (d, unit)
        else:
            result['dv'] = '0 %s [min]' % unit
        return result

    def Bailey_non_int(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'Kp',
            'iname': 'Ki',
            'dname': 'Kd',
        }
        if unit.lower().startswith('s'):
            ni = ni / 60
            nd = nd / 60
            unit = 'm'
        unit = ' %s' % unit
        ni = np / ni
        nd = np * nd
        result['pv'] = '%.3f/K' % np
        result['iv'] = '%.3f %s /K[reset/min]' % (ni, unit)
        if pidtype == 0:
            result['dv'] = '%.3f %s /K[min]' % (nd, unit)
        else:
            result['dv'] = '0 %s /K[min]' % (unit)
        return result

    def DeltaV_Series_PID_on_E(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'Gain',
            'iname': 'Tr',
            'dname': 'Td',
            'pv': '%.3f' % p,
            'iv': '%.3f %s' % (i, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (d, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def DeltaV_Standard_PID_on_E(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'Gain',
            'iname': 'Tr',
            'dname': 'Td',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Honeywell_int_A(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'K',
            'iname': 'T1',
            'dname': 'T2',
        }
        p = p * sprange / oprange
        if unit.lower().startswith('s'):
            i = i / 60
            d = d / 60
            unit = 'm'
        unit = ' %s' % unit
        i = 1 / i
        result['pv'] = '%.3f' % p
        result['iv'] = '%.3f %s' % (i, unit)
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (d, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Honeywell_nonint_A(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'K',
            'iname': 'T1',
            'dname': 'T2',
        }
        np = np * sprange / oprange;
        if unit.lower().startswith('s'):
            ni = ni / 60
            nd = nd / 60
            unit = 'm'
        unit = ' %s' % unit
        i = 1 / i
        result['pv'] = '%.3f' % np
        result['iv'] = '%.3f %s' % (ni, unit)
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Yokogawa_Centum_PID(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        np = 100 / (np * sprange / oprange)
        i = 1 / i
        result = {
            "pname": 'PB',
            'iname': 'TI',
            'dname': 'TD',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Siemens_S7_200(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'Kc',
            'iname': 'Ti',
            'dname': 'Td',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Interacting_A(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'K',
            'iname': 'Ti',
            'dname': 'Td',
            'pv': '%.3f' % p,
            'iv': '%.3f %s' % (i, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (d, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Non_interacting_A(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'K',
            'iname': 'Ti',
            'dname': 'Td',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Foxboro_int(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        p = 100 / (p * sprange / oprange);
        result = {
            "pname": 'PBAND',
            'iname': 'INT',
            'dname': 'DERIV',
            'pv': '%.3f' % p,
            'iv': '%.3f %s' % (i, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (d, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Foxboro_non_int(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        np = 100 / (np * sprange / oprange)
        result = {
            "pname": 'PBAND',
            'iname': 'INT',
            'dname': 'DERIV',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Supcon_Standard(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        ni = abs(10 * ni / np)
        nd = abs(10 * nd * np)
        np = np / 2
        unit = "0.1Sec"
        result = {
            "pname": 'K',
            'iname': 'Ti',
            'dname': 'Td',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Supcon_ECS700(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        np = 100 / (np * sprange / oprange)
        result = {
            "pname": 'PB',
            'iname': 'TI',
            'dname': 'TD',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        result['pidequ'] =  ' **** Supcon ECS-700 PID **** \n' 
        result['pidequ'] += '        MVRange     100            1         TD*s                          \n'
        result['pidequ'] += 'u(s) = --------- * ----- * (1 + ------ + --------------) * [SPT(s) - y(s)] \n'  
        result['pidequ'] += '        SPRange      PB          TI*s     1 + (TD/KD)s                     '
        result['latex'] = '''\\begin{equation} 
      u(s) = \\frac{MVRange}{SPRange} \\times \\frac{100}{PB} \\times (1 + \\frac{1}{TI \\times s} + \\frac{TD \\times s}{1 + \\frac{TD}{KD} s}) \\times [SPT(s) - y(s)]
      \\end{equation}'''
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def GuoDianZhiShen_NT_PLUS(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'PidGain',
            'iname': 'ResetTime',
            'dname': 'DGain',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        result['pidequ'] =  ' **** GuoDianZhiShen NT-PLUS PID **** \n' 
        result['pidequ'] += '                            1                                        \n'
        result['pidequ'] += 'u(s) = PidGain * (1 + ------------- + DGain * s) * [SPT(s) - y(s)]   \n' 
        result['pidequ'] += '                       ResetTime*s                                     '
        result['latex'] = '''\\begin{equation} 
      u(s) = PidGain \\times (1 + \\frac{1}{ResetTime \\times s} + DGain \\times s) \\times [SPT(s) - y(s)]
      \\end{equation}'''
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Supcon_FW247(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        ni = 10 * ni
        nd = 10 * nd
        result = {
            "pname": 'K',
            'iname': 'Ti',
            'dname': 'Td',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (ni, unit),
        }
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Matlab_Parallel(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'P',
            'iname': 'I',
            'dname': 'D',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (1 / ni / np, unit),
        }
        result['pidequ'] = f'P + I * (1/s) + D * N / (1 + N * (1/s))'
        result['latex'] = '''\\begin{equation} 
      P + I \\times \\frac{1}{s} + \\frac{D \\times N} {1 + N \\times \\frac{1}{s}}
      \\end{equation}'''
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd * np, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def Matlab_Ideal(self, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        result = {
            "pname": 'P',
            'iname': 'I',
            'dname': 'D',
            'pv': '%.3f' % np,
            'iv': '%.3f %s' % (1 / ni, unit),
        }
        result['pidequ'] = f'P * [1 + I * (1/s) + D * N / (1 + N * (1/s))]'
        result['latex'] = '''\\begin{equation} 
      P \\times [1 + I \\times \\frac{1}{s} + \\frac{D \\times N} {1 + N \\times \\frac{1}{s}}]
      \\end{equation}'''
        if pidtype == 0:
            result['dv'] = '%.3f %s' % (nd, unit)
        else:
            result['dv'] = '0 %s' % unit
        return result

    def calculate(self, dcstype, p, i, d, np, ni, nd, oprange, sprange, pidtype, unit):
        if dcstype in self.adapters:
            pid = self.adapters[dcstype](p, i, d, np, ni, nd, oprange, sprange, pidtype, unit)
            pid['pidstr']  = "%s = %s \n" % (pid['pname'], pid['pv'])
            pid['pidstr'] += "%s = %s \n" % (pid['iname'], pid['iv'])
            pid['pidstr'] += "%s = %s" % (pid['dname'], pid['dv'])
            pid.setdefault('pidequ', ' ')
            pid.setdefault('latex', '')
            return pid
        return None
