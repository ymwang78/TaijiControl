# coding=utf8
import platform
import os
import glob
from setuptools import setup
from setuptools import find_packages

__version__ = '0.9.25'

setup(
    name=f"tjdcs",
    version=__version__,
    author="TaijiControl",
    author_email="",
    description="tjdcs",
    keywords="tjdcs",
    packages=find_packages(),
    # setup_requires="" 指定安装的依赖，同样可以使用pip freeze > requirements.txt 生成依赖
    dependency_links=[],  # 添加依赖链接
    include_package_data = True,
    install_requires=[
        "numpy"
    ]
)